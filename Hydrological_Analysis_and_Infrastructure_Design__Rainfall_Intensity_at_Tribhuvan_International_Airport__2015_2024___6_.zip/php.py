# Rainfall intensity classification for Question 5
print(" DATA FOR QUESTION 5: Rainfall Intensity Classification\n")
print("="*60)

# IMD Classification
def classify_rainfall(rain):
    if rain == 0:
        return 'No Rain'
    elif rain <= 10:
        return 'Light'
    elif rain <= 35:
        return 'Moderate'
    elif rain <= 65:
        return 'Heavy'
    else:
        return 'Very Heavy'

df['Intensity_Category'] = df['Rainfall_mm'].apply(classify_rainfall)

print("IMD Rainfall Intensity Classification:")
print("-" * 60)
print("Category        | Range (mm/day)  | Description")
print("-" * 60)
print("No Rain         | 0               | Dry day")
print("Light           | 2.5 - 10        | Drizzle to light rain")
print("Moderate        | 10 - 35         | Moderate rainfall")
print("Heavy           | 35 - 65         | Heavy rainfall")
print("Very Heavy      | > 65            | Very heavy to extremely heavy")

# Calculate statistics for each category
intensity_stats = df.groupby('Intensity_Category').agg({
    'Rainfall_mm': ['count', 'sum', 'mean', 'max']
})
intensity_stats.columns = ['Days', 'Total_Rainfall_mm', 'Mean_mm', 'Max_mm']
intensity_stats['Percentage_Days'] = (intensity_stats['Days'] / len(df)) * 100
intensity_stats['Percentage_Rainfall'] = (intensity_stats['Total_Rainfall_mm'] / df['Rainfall_mm'].sum()) * 100

print("\nIntensity Category Statistics:")
print("="*60)
print(intensity_stats.round(2))

print("\n Key Findings:")
print("-" * 60)
for category in ['Light', 'Moderate', 'Heavy', 'Very Heavy']:
    if category in intensity_stats.index:
        days = intensity_stats.loc[category, 'Days']
        pct_days = intensity_stats.loc[category, 'Percentage_Days']
        pct_rainfall = intensity_stats.loc[category, 'Percentage_Rainfall']
        print(f"{category:15} | {days:4.0f} days ({pct_days:5.2f}%) | Contributes {pct_rainfall:5.2f}% of total rainfall")

# Design implications
print("\n Design Recommendations:")
print("="*60)
max_24hr = df['Rainfall_mm'].max()
print(f"Maximum 24-hour rainfall: {max_24hr:.1f} mm")
print(f"95th percentile (design storm): {df['Rainfall_mm'].quantile(0.95):.1f} mm")
print(f"99th percentile (extreme storm): {df['Rainfall_mm'].quantile(0.99):.1f} mm")
print("\nDrainage Design Considerations:")
print("-" * 60)
print(f"- Minimum design capacity: {df['Rainfall_mm'].quantile(0.95):.1f} mm/24hr")
print(f"- Recommended design capacity: {df['Rainfall_mm'].quantile(0.99):.1f} mm/24hr")
print(f"- Safety factor consideration: {max_24hr:.1f} mm/24hr (historical maximum)")
print(f"- Very heavy rainfall events: {intensity_stats.loc['Very Heavy', 'Days']:.0f} occurrences in 10 years")
print(f"  (Average: {intensity_stats.loc['Very Heavy', 'Days']/10:.1f} events per year)")

print("\n" + "="*60)